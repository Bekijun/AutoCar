# AutoCar

> DOCKER와 ROS2를 이용하여 가상환경에서 자율주행을 학습하기 위한 코드입니다.

## 준비사항

- ROS2 FOXY(20.04)
- DOCKER(4.33.0)
